import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('insurance.csv')

df_encoded = pd.get_dummies(df, columns=['sex', 'smoker', 'region'],drop_first=True)
df_encoded = df_encoded.astype(int)
print(df_encoded)


print(df_encoded)

sex_counts = df_encoded['sex_male'].value_counts()


labels = ['Female (0)', 'Male (1)']
sizes = [sex_counts[0], sex_counts[1]]

plt.figure(figsize=(8, 6))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90, colors=['lightcoral', 'lightskyblue'])
plt.title('Proportion of Sex in the Dataset')
plt.axis('equal')
plt.show()

plt.figure(figsize=(8, 6))
sns.boxplot(x='sex_male', y='charges', data=df_encoded, palette='Set2')
plt.xlabel('Sex (0 = Female, 1 = Male)')
plt.ylabel('Charges')
plt.title('Boxplot of Charges by Sex')
plt.show()

