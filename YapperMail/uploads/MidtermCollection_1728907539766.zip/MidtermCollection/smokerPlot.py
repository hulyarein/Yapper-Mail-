import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv('insurance.csv')


df_encoded = pd.get_dummies(df, columns=['sex', 'smoker', 'region'],drop_first=True)
df_encoded = df_encoded.astype(int)
print(df_encoded)


print(df_encoded)


sex_counts = df_encoded['smoker_yes'].value_counts()


labels = ['Non-smoker (0)', 'Smoker (1)']
sizes = [sex_counts[0], sex_counts[1]]


plt.figure(figsize=(8, 6))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90, colors=['lightcoral', 'lightskyblue'])
plt.title('Proportion of Smokers in the Dataset')
plt.axis('equal')  
plt.show()


plt.figure(figsize=(8, 6))
sns.boxplot(x='smoker_yes', y='charges', data=df_encoded, palette='Set2')
plt.xlabel('Smoker (0 = No, 1 = Yes)')
plt.ylabel('Charges')
plt.title('Boxplot of Charges by Smoker')
plt.show()

