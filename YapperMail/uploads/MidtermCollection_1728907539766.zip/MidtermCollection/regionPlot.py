import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


df = pd.read_csv('insurance.csv')


southeast_rows = df[df['region'] == 'southeast']
southwest_rows = df[df['region'] == 'southwest']
northeast_rows = df[df['region'] == 'northeast']
northwest_rows = df[df['region'] == 'northwest']


fig, axs = plt.subplots(4, 2, figsize=(12, 16))
fig.suptitle('Histogram and Density Plots of Charges by Region', fontsize=16)


def plot_hist_and_density(data, ax_hist, ax_density, region_name, color):
   
    sns.histplot(data['charges'], bins=10, ax=ax_hist, color=color, alpha=0.5, edgecolor='black')
    ax_hist.set_xlabel('Charges')
    ax_hist.set_ylabel('Density')
    ax_hist.grid(axis='y', alpha=0.75)
    
    
    ax_hist.text(-0.1, 0.9, region_name, transform=ax_hist.transAxes, fontsize=10, weight='bold', ha='center', va='top')
    
   
    sns.kdeplot(data['charges'], ax=ax_density, color=color, fill=True, alpha=0.3)
    ax_density.set_xlabel('Charges')
    ax_density.set_ylabel('Density')
    ax_density.grid(axis='y', alpha=0.75)


plot_hist_and_density(southeast_rows, axs[0, 0], axs[0, 1], 'Southeast', 'blue')


plot_hist_and_density(southwest_rows, axs[1, 0], axs[1, 1], 'Southwest', 'green')


plot_hist_and_density(northeast_rows, axs[2, 0], axs[2, 1], 'Northeast', 'orange')


plot_hist_and_density(northwest_rows, axs[3, 0], axs[3, 1], 'Northwest', 'purple')


plt.tight_layout(rect=[0, 0, 1, 0.96])  
plt.show()




'''BOXPLOT'''
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


df = pd.read_csv('insurance.csv')


plt.figure(figsize=(10, 6))
sns.boxplot(x='region', y='charges', data=df, palette='Set2')

plt.title('Box Plot of Charges by Region', fontsize=16)
plt.xlabel('Region', fontsize=12)
plt.ylabel('Charges', fontsize=12)


plt.show()

