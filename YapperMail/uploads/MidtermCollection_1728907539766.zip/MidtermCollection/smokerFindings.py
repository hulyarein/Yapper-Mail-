import pandas as pd
from scipy import stats


df = pd.read_csv('insurance.csv')


df_encoded = pd.get_dummies(df, columns=['sex', 'smoker', 'region'],drop_first=True)
df_encoded = df_encoded.astype(int)




smoker_columns = [col for col in df_encoded.columns if 'smoker' in col]
df_smoker = df_encoded[smoker_columns]

print(df_smoker)


mean = df_smoker .mean()
median = df_smoker .median()
mode = df_smoker .mode()  
std_dev = df_smoker .std()
variance = df_smoker .var()
minimum = df_smoker .min()
maximum = df_smoker .max()
data_range = maximum - minimum
percentiles = df_smoker .describe(percentiles=[0.25, 0.5, 0.75]).loc[['25%', '50%', '75%']]


print("Mean:", mean)
print("Median:", median)
print("Mode:", mode)
print("Standard Deviation:", std_dev)
print("Variance:", variance)
print("Minimum:", minimum)
print("Maximum:", maximum)
print("Range:", data_range)
print("Percentiles (25th, 50th, 75th):", percentiles)


stats_describe = stats.describe(df_smoker)
print("Scipy stats.describe:", stats_describe)